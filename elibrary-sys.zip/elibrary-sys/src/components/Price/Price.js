import './Price.css';
function Price(){
    return(<div>
        <h2 className="rules"><center>Price card</center></h2>

    </div>)
}
export default Price;